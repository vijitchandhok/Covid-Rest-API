package com.covid.covidrest.services;

import java.util.List;

import com.covid.covidrest.entity.Country;


public interface CountryService {

	List<Country> getCountries();

	Country getCountry(String countryName);

	Country addCountry(Country country);

	Country updateCountry(Country country);

	void deleteCountry(String country);
}
