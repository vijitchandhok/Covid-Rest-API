package com.covid.covidrest.services;

import java.io.IOException;
import java.util.List;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.covid.covidrest.covidapi.CovidAPI;
import com.covid.covidrest.covidapi.CovidAPIImpl;
import com.covid.covidrest.dao.CountryDao;
import com.covid.covidrest.entity.Country;

@Service
public class CountryServiceImpl implements CountryService {
	@Autowired
	CountryDao countryDao;
	
	public CountryServiceImpl() {}

	@Override
	public List<Country> getCountries() {		
		return countryDao.findAll();
	}

	@Override
	public Country getCountry(String countryName) {
		Country country=null;
		try {
			country= countryDao.findById(countryName).get();	
		}
		catch (Exception e){
			CovidAPI covidAPI= new CovidAPIImpl();
			try {
				country=covidAPI.getCountry(countryName);
			} catch (IOException | InterruptedException | JSONException e1) {
				
				e1.printStackTrace();
			}
			country=updateCountry(country);
		}
		return country;
	}
	
	@Override
	public Country addCountry(Country country) {
		countryDao.save(country);
		return country;
	}
	
	@Override
	public Country updateCountry(Country country) {
		countryDao.save(country);
		return country;
	}
	
	@Override
	public void  deleteCountry(String country) {
		Country entity=countryDao.getOne(country);
		countryDao.delete(entity);
	}

	

}
