package com.covid.covidrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CovidrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CovidrestApplication.class, args);
	}

}
