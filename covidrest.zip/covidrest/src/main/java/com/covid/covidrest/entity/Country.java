package com.covid.covidrest.entity;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Country {
	@Id
	private String country;
	private String confirmed;
	private String recovered;
	private String deaths;
	private String lastUpdateTime;
	
	public Country(String country, String confirmed, String recovered, String deaths, String lastUpdateTime) {
		
		this.country = country;
		this.confirmed = confirmed;
		this.recovered = recovered;
		this.deaths = deaths;
		this.lastUpdateTime = lastUpdateTime;
	}
	public Country() {
		super();
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getConfirmed() {
		return confirmed;
	}
	public void setConfirmed(String confirmed) {
		this.confirmed = confirmed;
	}
	public String getRecovered() {
		return recovered;
	}
	public void setRecovered(String recovered) {
		this.recovered = recovered;
	}
	public String getDeaths() {
		return deaths;
	}
	public void setDeaths(String deaths) {
		this.deaths = deaths;
	}
	public String getLastUpdateTime() {
		return lastUpdateTime;
	}
	public void setLastUpdateTime(String lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}
}
