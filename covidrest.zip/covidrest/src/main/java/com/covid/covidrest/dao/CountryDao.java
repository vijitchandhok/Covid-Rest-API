package com.covid.covidrest.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.covid.covidrest.entity.Country;

public interface CountryDao extends JpaRepository<Country,String>  {

}
