package com.covid.covidrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.covid.covidrest.entity.Country;
import com.covid.covidrest.services.CountryService;


@RestController
public class MyController {
	@Autowired
	CountryService countryService;
	
	@GetMapping("/home")
	public String home() {
		return "Welcome to Covid Stats App";
	}
	
	@GetMapping("/countries")
	public List<Country> getCountries(){
		return this.countryService.getCountries();
	}
	
	@GetMapping("/countries/{countryName}")
	public Country getCountry(@PathVariable String countryName){
		return this.countryService.getCountry(countryName);
	}
	
	@PostMapping("/countries")
	public Country addCountry(@RequestBody Country country){
		return this.countryService.addCountry(country);
	}
	
	@PutMapping("/countries")
	public Country updateCountry(@RequestBody Country country){
		return this.countryService.updateCountry(country);
	}
	
	@DeleteMapping("/countries/{countryName}")
	public ResponseEntity<HttpStatus> deleteCountry(@PathVariable String countryName){
		try {
			this.countryService.deleteCountry(countryName);
			return new ResponseEntity<>(HttpStatus.OK);
		}
		catch(Exception e){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
