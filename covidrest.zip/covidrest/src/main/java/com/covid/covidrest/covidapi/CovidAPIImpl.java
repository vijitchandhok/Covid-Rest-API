package com.covid.covidrest.covidapi;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.json.JSONException;
import org.json.JSONObject;

import com.covid.covidrest.entity.Country;

public class CovidAPIImpl implements CovidAPI	 {
	
	public Country getCountry(String country1) throws IOException, InterruptedException, JSONException {		
		var url ="https://covid19.mathdro.id/api/countries/"+ country1;
		var request=HttpRequest.newBuilder().GET().uri(URI.create(url)).build();
		var client= HttpClient.newBuilder().build();
		var response=client.send(request, HttpResponse.BodyHandlers.ofString());
		String jsonString =response.body() ; 
		JSONObject obj = new JSONObject(jsonString);
		int confirmedCases = obj.getJSONObject("confirmed").getInt("value");
		int recoveredCases = obj.getJSONObject("recovered").getInt("value");
		int deaths= obj.getJSONObject("deaths").getInt("value");
		String lastUpdatedTime=obj.get("lastUpdate").toString();
		Country country= new Country(country1, String.valueOf(confirmedCases), String.valueOf(recoveredCases),String.valueOf(deaths), lastUpdatedTime); 
		return country;
		
	}
}
