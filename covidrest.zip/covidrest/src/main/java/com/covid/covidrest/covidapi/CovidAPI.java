package com.covid.covidrest.covidapi;

import java.io.IOException;

import org.json.JSONException;

import com.covid.covidrest.entity.Country;

public interface CovidAPI {
	public Country getCountry(String country1) throws IOException, InterruptedException, JSONException;
}